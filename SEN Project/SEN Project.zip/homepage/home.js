
$(document).ready(function(){
$('.navbar-light > button').on('click', function(){
    $('.navbar-light').toggleClass('color-changed');
});
});